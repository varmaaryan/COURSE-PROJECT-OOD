import shutil

import os

# # Get the current directory
# current_directory = os.getcwd()

# # Get all the folder names in the current directory
# folder_names = [folder for folder in os.listdir(current_directory) if os.path.isdir(os.path.join(current_directory, folder))]

# # Print the folder names
# for folder_name in folder_names:
#     # Move into the folder
#     os.chdir(os.path.join(current_directory, folder_name))
    
#     # Get all the file names in the folder
#     file_names = [file for file in os.listdir() if os.path.isfile(file)]
    
#     # Rename the files if they don't match the folder name
#     for file_name in file_names:
#         if ".xml" in file_name:
#             new_file_name = folder_name + "_" + "design_pattern.xml"
#             os.rename(file_name, new_file_name)



# Get the current directory
current_directory = os.getcwd()

# Get all the folder names in the current directory
folder_names = [folder for folder in os.listdir(current_directory) if os.path.isdir(os.path.join(current_directory, folder))]

# Copy the content of each folder into the current directory
for folder_name in folder_names:
    # Get the path of the folder
    folder_path = os.path.join(current_directory, folder_name)
    
    # Get all the file names in the folder
    file_names = [file for file in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, file))]
    
    # Copy the files one at a time
    for file_name in file_names:
        # Get the source file path
        source_file_path = os.path.join(folder_path, file_name)
        
        # Get the destination file path
        destination_file_path = os.path.join(current_directory, file_name)
        
        # Copy the file
        shutil.copy(source_file_path, destination_file_path)
    
# # Remove all the folders
# for folder_name in folder_names:
#     # Get the path of the folder
#     folder_path = os.path.join(current_directory, folder_name)
    
#     # Remove the folder
#     shutil.rmtree(folder_path)